#ifndef TAREFA_H
#define TAREFA_H

typedef struct Tarefa {
    int id;
    char descricao[100];
    int tempoLimite; // em horas
    int situacao; // 0 para ativa, 1 para concluída
    struct Tarefa* proxima;
} Tarefa;

// Funções
Tarefa* criarTarefa(int id, const char* descricao, int tempoLimite);
void adicionarTarefa(Tarefa** lista, int id, const char* descricao, int tempoLimite);
void visualizarTarefas(Tarefa* lista, int filtro);
void visualizarTarefasOrdenadas(Tarefa* lista);
void concluirTarefa(Tarefa* lista, int id);
void excluirTarefa(Tarefa** lista, int id);

#endif
