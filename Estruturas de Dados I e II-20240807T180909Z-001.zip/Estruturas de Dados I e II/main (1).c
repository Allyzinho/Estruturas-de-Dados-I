#include <stdio.h>
#include <stdlib.h>
#include "tarefa.h"
#include "tarefa.c"

void menu() {
    printf("1. Adicionar Tarefa\n");
    printf("2. Visualizar Todas as Tarefas\n");
    printf("3. Visualizar Tarefas Ativas\n");
    printf("4. Visualizar Tarefas Concluídas\n");
    printf("5. Visualizar Tarefas Ordenadas\n");
    printf("6. Concluir Tarefa\n");
    printf("7. Excluir Tarefa\n");
    printf("0. Sair\n");
    printf("Escolha uma opção: ");
}

int main() {
    Tarefa* lista = NULL;
    int opcao, id, tempoLimite;
    char descricao[100];

    do {
        menu();
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("ID: ");
                scanf("%d", &id);
                printf("Descricao: ");
                scanf(" %[^\n]s", descricao);
                printf("Tempo Limite (em horas): ");
                scanf("%d", &tempoLimite);
                adicionarTarefa(&lista, id, descricao, tempoLimite);
                break;
            case 2:
                visualizarTarefas(lista, -1); // Todas as tarefas
                break;
            case 3:
                visualizarTarefas(lista, 0); // Tarefas ativas
                break;
            case 4:
                visualizarTarefas(lista, 1); // Tarefas concluídas
                break;
            case 5:
                visualizarTarefasOrdenadas(lista); // Tarefas ordenadas
                break;
            case 6:
                printf("ID da Tarefa a Concluir: ");
                scanf("%d", &id);
                concluirTarefa(lista, id);
                break;
            case 7:
                printf("ID da Tarefa a Excluir: ");
                scanf("%d", &id);
                excluirTarefa(&lista, id);
                break;
            case 0:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida!\n");
        }
    } while (opcao != 0);

    return 0;
}
