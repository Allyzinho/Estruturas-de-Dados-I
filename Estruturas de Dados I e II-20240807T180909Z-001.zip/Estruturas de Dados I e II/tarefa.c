#include "tarefa.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Tarefa* criarTarefa(int id, const char* descricao, int tempoLimite) {
    Tarefa* novaTarefa = (Tarefa*)malloc(sizeof(Tarefa));
    novaTarefa->id = id;
    strcpy(novaTarefa->descricao, descricao);
    novaTarefa->tempoLimite = tempoLimite;
    novaTarefa->situacao = 0; // Ativa
    novaTarefa->proxima = NULL;
    return novaTarefa;
}

void adicionarTarefa(Tarefa** lista, int id, const char* descricao, int tempoLimite) {
    Tarefa* novaTarefa = criarTarefa(id, descricao, tempoLimite);
    novaTarefa->proxima = *lista;
    *lista = novaTarefa;
}

void visualizarTarefas(Tarefa* lista, int filtro) {
    Tarefa* atual = lista;
    while (atual != NULL) {
        if (filtro == -1 || atual->situacao == filtro) {
            printf("ID: %d\nDescricao: %s\nTempo Limite: %d\nSituacao: %s\n\n",
                   atual->id, atual->descricao, atual->tempoLimite,
                   atual->situacao == 0 ? "Ativa" : "Concluida");
        }
        atual = atual->proxima;
    }
}

void visualizarTarefasOrdenadas(Tarefa* lista) {
    // Copiar tarefas para um array para ordenação
    Tarefa* array[100]; // Limite de 100 tarefas
    int count = 0;
    Tarefa* atual = lista;
    while (atual != NULL) {
        array[count++] = atual;
        atual = atual->proxima;
    }

    // Ordenar tarefas ativas por tempo limite
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (array[i]->situacao == 0 && array[j]->situacao == 0 && array[i]->tempoLimite > array[j]->tempoLimite) {
                Tarefa* temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }

    // Exibir tarefas ordenadas
    for (int i = 0; i < count; i++) {
        printf("ID: %d\nDescricao: %s\nTempo Limite: %d\nSituacao: %s\n\n",
               array[i]->id, array[i]->descricao, array[i]->tempoLimite,
               array[i]->situacao == 0 ? "Ativa" : "Concluida");
    }
}

void concluirTarefa(Tarefa* lista, int id) {
    Tarefa* atual = lista;
    while (atual != NULL) {
        if (atual->id == id) {
            atual->situacao = 1; // Concluída
            return;
        }
        atual = atual->proxima;
    }
}

void excluirTarefa(Tarefa** lista, int id) {
    Tarefa* atual = *lista;
    Tarefa* anterior = NULL;
    while (atual != NULL && atual->id != id) {
        anterior = atual;
        atual = atual->proxima;
    }
    if (atual == NULL) return;
    if (anterior == NULL) {
        *lista = atual->proxima;
    } else {
        anterior->proxima = atual->proxima;
    }
    free(atual);
}
