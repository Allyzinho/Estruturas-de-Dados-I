#include <stdio.h>

int main(){

    int positivo, negativo, n1, n2, n3, n4;

    printf("N1: ");
    scanf("%d", &n1);
    printf("N2: ");
    scanf("%d", &n2);
    printf("N3: ");
    scanf("%d", &n3);
    printf("N4: ");
    scanf("%d", &n4);

    positivo = 0;
    negativo = 0;

    if (n1 >= 0){
        positivo++;
    }
    else {
        negativo++;
    }
    if (n2 >= 0){
        positivo++;
    }
    else {
        negativo++;
    }
    if (n3 >= 0){
        positivo++;
    }
    else {
        negativo++;
    }
    if (n4 >= 0){
        positivo++;
    }
    else {
        negativo++;
    }
        printf("%d (+) e %d (-) \n", positivo, negativo);
        
        return 0;
}