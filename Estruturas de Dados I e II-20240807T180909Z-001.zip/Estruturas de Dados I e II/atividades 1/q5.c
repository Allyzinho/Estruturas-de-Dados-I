#include <stdio.h>

int main(){

    int top;

    printf("Posição: ");
    scanf("%d", &top);

    if (top <= 5){
        printf("Top 5");
    }
    else if (top > 5 && top <= 10){
        printf("Top 10");
    }
    else if (top > 10 && top <= 20){
        printf("Top 20");
    }
    else if (top > 20 && top <= 30){
        printf("Top 30");
    }
    else {
        printf("Top 100");
    }

    return 0;
}