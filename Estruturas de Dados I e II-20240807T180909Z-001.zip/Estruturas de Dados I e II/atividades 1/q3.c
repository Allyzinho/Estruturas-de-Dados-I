#include <stdio.h>

int main(){

    int duracao, inicio, fim;

    printf("Início: ");
    scanf("%d", &inicio);
    printf("Fim: ");
    scanf("%d", &fim);

    if (inicio > fim){
        duracao = (24 - inicio) + fim;
        printf("Duração: %d horas\n", duracao);
    }
    else if(inicio < fim){
        duracao = fim - inicio;
        printf("Duração: %d horas\n", duracao);
    }
    else if(inicio || fim > 24) {
        printf("Evento não pode execeder 24 horas \n");
    }
    return 0;
}