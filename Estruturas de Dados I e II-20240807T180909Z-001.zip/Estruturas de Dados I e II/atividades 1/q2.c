#include <stdio.h>

int main(){

    int pagamento;
    double preco;

    printf("Preço do produto: ");
    scanf("%lf", &preco);
    printf("Forma de pagamento: ");
    scanf("%d", &pagamento);

    if (pagamento == 1){
        preco = preco - (preco * 0.05);
        printf("Preço a vista: %.2lf \n", preco);
    }
    else if (pagamento == 2){
        preco = preco + (preco * 0.10);
        printf("Preço a prazo: %.2lf \n", preco);
    }
    else{
        printf("Forma de pagamento invalida\n");
    }
    return 0;
}