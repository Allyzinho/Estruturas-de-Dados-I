#include <stdio.h>

int main(){

    int idade;

    printf("Idade: ");
    scanf("%d", &idade);

    if (idade >= 18 && idade <=70){
        printf("Voto obrigatório");
    }
    else if (idade < 16){
        printf("Não pode votar");
    }
    else{
        printf("Voto facultativo");
    }
    return 0;
}