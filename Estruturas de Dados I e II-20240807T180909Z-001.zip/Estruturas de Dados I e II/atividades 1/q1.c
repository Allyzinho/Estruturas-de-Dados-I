#include <stdio.h>

int main(){

    int horas_t;
    double valor_hora, salario;
    
    printf("Horas trabalhadas: ");
    scanf("%d", &horas_t);
    printf("Valor da hora: ");
    scanf("%lf", &valor_hora);
    salario = horas_t * valor_hora;
    
    if (horas_t > 200){
        salario = salario + (salario * 0.05);
        printf("Salario: %.2lf \n", salario);
    }
    else{
        printf("Salario: %.2lf \n", salario);
    }
    return 0;
}