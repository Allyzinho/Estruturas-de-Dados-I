#include "producao34-07.h"

#include <stdio.h>

int main(void) {
  Sentinela s;
  s.head = NULL;
  s.tail = NULL;

  int opcao;
  do {
    menu();
    scanf("%d", & opcao);

    switch (opcao) {
    case 1:
      s = incluirProducao(s);
      break;
    case 2: {
      if (s.head == NULL) {
        printf("Nenhum registro cadastrado.\n");
        break;
      }
      int consultaOpcao;
      printf("1. Consultar por data\n2. Consultar por Cultivar\n3. Voltar\n");
      scanf("%d", & consultaOpcao);
      if (consultaOpcao == 1) {
        Data data;
        printf("Data da produção (ex: 11 12 2023): ");
        scanf("%d %d %d", & data.dia, & data.mes, & data.ano);
        consultarData(data, s);
      } else if (consultaOpcao == 2) {
        char cultivar[20];
        printf("Cultivar: ");
        scanf("%s", cultivar);
        consultarCultivar(s, cultivar);
      }
      break;
    }
    case 3: {
      if (s.head == NULL) {
        printf("Nenhum registro cadastrado.\n");
        break;
      }
      int codigo;
      printf("Informe o código da produção que deseja alterar: ");
      scanf("%d", & codigo);
      alterarProducao(s, codigo);
      break;
    }
    case 4:
      if (s.head != NULL) {
        s = excluirProducao(s);
      } else {
        printf("Nenhum registro cadastrado.\n");
      }
      break;
    case 5:
      if (s.head != NULL) {
        listarTudo(s);
      } else {
        printf("Nenhum registro cadastrado.\n");
      }
      break;
    case 6:
      printf("Programa finalizado.\n");
      break;
    default:
      printf("Opção inválida. Tente novamente.\n");
    }
  } while (opcao != 6);

  return 0;
}
