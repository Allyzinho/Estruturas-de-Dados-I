#include <stdio.h>
#include <stdlib.h>


//structs
typedef struct data{
   int dia;
   int mes;
   int ano;
} Data;

typedef struct fardo{
   char cultivar[20];
   char tipoDeFeno;
   int diametro;
} Fardo;


typedef struct producao{
   int codigo;
   Data dataProducao;
   Fardo tipoDeFardo;  
   int qtDeFardos;
   float duracao;
    struct producao *next;  
    struct producao *prev; 
} Producao;




typedef struct Lista{
    struct producao* head;
    struct producao* tail;
} Lista;

//declaração de funções
void menu(struct Lista* lista);
void criarFardo(struct Lista* lista);
void editar(Lista* lista);
void excluir(Lista* lista);
void imprimirLista(Lista* lista);
void imprimir(Lista* lista);


//main
int main()
{
    
    Lista* lista = malloc(sizeof(Lista));
    lista->head = NULL;
    lista->tail = NULL;
    menu(lista);

}

//função
void menu(struct Lista* lista)
{
        
        while(1)
        {
            printf("Bem vindo ao menu, digite o comando desejado, ou 0 para ajuda\n");
            printf("1 = adicionar;\n2 = imprimir 1;\n3 = editar;\n4 = exlcuir;\n5 = imprimir toda a lista;\n");
            while (getchar() != '\n');

            char escolha;
            scanf("%c", &escolha);

            if(escolha == '6')
            {
                exit(0);
            }
            else if(escolha == '1')
            {
                criarFardo(lista);
                
                
            }
            else if(escolha == '2')
            {
                
                imprimir(lista);
                menu(lista);
                
            }
            else if(escolha== '3')
            {
                editar(lista);
            }
            else if(escolha == '4')
            {
                excluir(lista);
                menu(lista);
            }
            else if(escolha =='5')
            {
                imprimirLista(lista);
                menu(lista);
            }
            else if(escolha == '0')
            {
                //ajuda
                printf("1 = adicionar;\n2 = imprimir 1;\n3 = editar;\n4 = exlcuir;\n5 = imprimir toda a lista;\n");
            }
           else{
            printf("comando invalido, redirecionado ao menu;\n");
            continue;
            }
                
            

        }
}




void criarFardo(struct Lista* lista)
{
    printf("Digite o codigo da producao:\n");
    int codigo;
    scanf("%d", &codigo);
    
    Producao *prod = malloc(sizeof(Producao));
   
    prod->codigo = codigo;
    printf("insira o dia mes ano separados por um espaco\n");
    scanf("%d %d %d", &prod->dataProducao.dia, &prod->dataProducao.mes, &prod->dataProducao.ano);

    printf("insira o nome da cultivare\n");
    scanf("%s", prod->tipoDeFardo.cultivar);

    printf("insira o tipo de feno\n");
    scanf(" %c", &prod->tipoDeFardo.tipoDeFeno);

    printf("insira o diamentro\n");
    scanf("%d", &prod->tipoDeFardo.diametro);

    printf("digite a qualtidade de fardos:\n");
    scanf("%d", &prod->qtDeFardos);

    printf("digite a duracao:\n");
    scanf("%f", &prod->duracao);
    

    //Producao* aux;
    if( lista->head == NULL)
    {
        lista->head = prod;
        lista->tail= prod;
        prod->next = NULL;
        prod ->prev = NULL;
        printf("fardo adicionado com exito.\n");
        
    }
    else{
        lista->tail->next = prod;
        prod->prev = lista->tail;
        lista->tail = prod;
        prod->next = NULL;
        printf("fardo adicionado com exito.\n");
       
    }
    return;
}

void editar(Lista* lista)
{
    int id;
    printf("qual o id q voce deseja mudar:\n");
    scanf("%d", &id);
    Producao* aux;
    for (aux = lista->head; aux != NULL; aux = aux->next) {
        if(aux->codigo == id)
        {
            printf("producao encontrada!\n");
            printf("Digite o novo codigo,Codigo atual: %d\n", aux->codigo);
            int codigo;
            scanf("%d", &codigo);
            aux->codigo = codigo;

            printf("Digite a nova dada, Data atua de Producao: %02d/%02d/%04d\n", aux->dataProducao.dia, aux->dataProducao.mes, aux->dataProducao.ano);
            scanf("%d %d %d", &aux->dataProducao.dia, &aux->dataProducao.mes, &aux->dataProducao.ano);

            printf("Digite o novo nome, nome atual da cultivar: %s\n", aux->tipoDeFardo.cultivar);
            scanf("%s", aux->tipoDeFardo.cultivar);
            
            printf("Digite o novo tipo de feno, tipo atual de feno: %c\n", aux->tipoDeFardo.tipoDeFeno);
            scanf(" %c", &aux->tipoDeFardo.tipoDeFeno);

            printf("Digite o novo diamentro, diametro atual: %d\n", aux->tipoDeFardo.diametro);
            scanf("%d", &aux->tipoDeFardo.diametro);

            printf("digite a nova quantidade de fardos, atual: %d\n", aux->qtDeFardos);
            scanf("%d", &aux->qtDeFardos);


            printf("Digite a nova duracao, duracao atual: %f\n", aux->duracao);
            scanf("%f", &aux->duracao);
        }
    }
}

void excluir(Lista* lista)
{
    printf("digite o id que voce deseje deletar:\n");
    int id;
    scanf("%d", &id);
    Producao* aux;
    for(aux = lista->head;aux != NULL; aux= aux->next)
    {
        if(id == aux->codigo)
        {   
            if(aux == lista->tail && aux ==lista->head)
            {
                lista->head = NULL;
                lista->tail = NULL;
                free(aux);
            }
            else if(aux->next == NULL)
            {
                lista->tail = aux->prev;
                lista->tail->next = NULL;
                free(aux);
            }
            else if(aux->prev == NULL)
            {
                lista->head = aux->next;
                lista->head->prev = NULL;
                free(aux);
            }
            else{
                aux->prev->next = aux->next;
                aux->next->prev = aux->prev;
                free(aux);
                
                }
            printf("removido com exito\n");
            return;
        }
    }
    printf("id nao encontrado\n");
    return;
}



void imprimirLista(Lista* lista) {
    if (lista->head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    Producao* aux;

    printf("Lista de Producao:\n");

    for (aux = lista->head; aux != NULL; aux = aux->next) {
        printf("Codigo: %d\n", aux->codigo);
        printf("Data de Producao: %02d/%02d/%04d\n", aux->dataProducao.dia, aux->dataProducao.mes, aux->dataProducao.ano);
        printf("Nome da cultivar: %s\n", aux->tipoDeFardo.cultivar);
        printf("Tipo de Feno: %c\n", aux->tipoDeFardo.tipoDeFeno);
        printf("Diametro: %d\n", aux->tipoDeFardo.diametro);
        printf("Quantidade de Fardos: %d\n", aux->qtDeFardos);
        printf("Duracao: %f\n", aux->duracao);

        printf("\n");
    }
}

void imprimir(Lista* lista) {
    if (lista->head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }
    int id;
    printf("digite o id que voce quer encontrar\n");
    scanf("%d", &id);
    Producao* aux;

    printf("Lista de Producao:\n");

    for (aux = lista->head; aux != NULL; aux = aux->next) {
        if(aux->codigo == id){
        printf("Codigo: %d\n", aux->codigo);
        printf("Data de Producao: %02d/%02d/%04d\n", aux->dataProducao.dia, aux->dataProducao.mes, aux->dataProducao.ano);
        printf("Nome da cultivar: %s\n", aux->tipoDeFardo.cultivar);
        printf("Tipo de Feno: %c\n", aux->tipoDeFardo.tipoDeFeno);
        printf("Diametro: %d\n", aux->tipoDeFardo.diametro);
        printf("Quantidade de Fardos: %d\n", aux->qtDeFardos);
        printf("Duracao: %f\n", aux->duracao);

        printf("\n");
        return;
        }
    }
    printf("id nao encontrado\n");
}
