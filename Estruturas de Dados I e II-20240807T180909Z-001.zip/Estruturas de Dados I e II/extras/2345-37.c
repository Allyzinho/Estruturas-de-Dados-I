#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "2345-37Feno.h"

int main(){
    Producao *first=NULL;
    menu(first);
    return 0;
}
