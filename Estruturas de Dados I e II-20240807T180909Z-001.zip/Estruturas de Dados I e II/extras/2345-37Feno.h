typedef struct fardo{ 
    char cultivar[20]; 
    char tipoDeFeno; 
    int diametro;
} Fardo;

typedef struct data{ 
    int dia;
    int mes;
    int ano;
} Data;

typedef struct producao{ 
    int codigo;
    Data data; 
    Fardo tipoFardo; 
    int qtFardos; 
    float duracao;
    struct producao *next, *prev;
} Producao;

int ifExist(Producao *first, int x);
void printProd(Producao *p);
Producao *incluirProd(Producao *first);
Producao *excluirProd(Producao *first,int codigo);
void alterarProd(Producao *first, int codigo);
void printTudo(Producao *first);
void consultaProd(Producao *first);
void menu(Producao *first);
