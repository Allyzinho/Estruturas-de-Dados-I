#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct data{
   int dia;
   int mes;
   int ano;
} Data;
typedef struct fardo{
   int cultivar;
   char tipoDeFeno;
   int diametro;
} Fardo;
typedef struct producao{
   int codigo;
   Data dataProducao;
   Fardo tipoDeFardo;  
   int qtDeFardos;
   float duracao;
   struct producao *next, *prev;
} Producao;


int verificaCod(int a, Producao* first){
    Producao *aux = NULL;
    if(first==NULL)return 0;
    for (aux=first;aux!=NULL;aux=aux->next){
        if(aux->codigo==a)return 1;//tem igual 
    }
    return 0;//cod unico
}

int transformaEmNumero(const char *nome) {
    if (strcmp(nome, "Tifton85") == 0) {
        return 0;
    } else if (strcmp(nome, "Florakirk") == 0) {
        return 1;
    } else if (strcmp(nome, "Jiggs") == 0) {
        return 2;
    } else if (strcmp(nome, "Coastcross") == 0) {
        return 3;
    } else {
        return -1;
    }
}

char* transformaEmNome(int numero) {
    switch (numero) {
        case 0:
            return "Tifton85";
        case 1:
            return "Florakirk";
        case 2:
            return "Jiggs";
        case 3:
            return "Coastcross";
        default:
            return "Desconhecido";
    }
}

Producao* incluirProducao(Producao* first){
    Producao *prod;
    prod = (Producao*)malloc(sizeof(Producao));
    Fardo fardo;
    int cod;
    char cult[20];
    
    printf("\nDigite o cultivar do fardo: ");
    scanf("%s", cult);
    fardo.cultivar = transformaEmNumero(cult);

    printf("\nDigite o tipo de feno do fardo(A, B ou C): ");
    scanf(" %c", &fardo.tipoDeFeno);
    
    printf("\nDigite o diâmetro do fardo: ");
    scanf("%d", &fardo.diametro);

    printf("\nDigite o código da produção: ");
    scanf("%d", &cod);
    if(verificaCod(cod, first)==1){
        printf("\nCódigo já está sendo usado. Operação cancelada");
        return first;
    }

    printf("Data da produção, no formato 00 00 0000 (dia mês ano): ");
    scanf("%d %d %d", &prod->dataProducao.dia, &prod->dataProducao.mes, &prod->dataProducao.ano);


    printf("\nDigite a quantidade de fardos da produção: ");
    scanf(" %d", &prod->qtDeFardos);

    printf("Duração da produção: ");
    scanf(" %f", &prod->duracao);
    
    prod->codigo = cod;
    prod->tipoDeFardo = fardo;
    prod->next = NULL;
    prod->prev = NULL;
    Producao *aux = NULL;
    if(first==NULL){
        first = prod;
        return first;
    }else{
        for (aux=first;aux->next!=NULL;aux=aux->next);
        aux->next = prod;
        prod->prev = aux;
        return first;
    }
}
void listarTodos(Producao* first){
    Producao *aux;
    for(aux=first; aux!=NULL; aux=aux->next){
        printf("Cód: %d - %d/%d/%d\n - %d fardo(s) e duração de %.2f\n",aux->codigo, aux->dataProducao.dia, aux->dataProducao.mes, aux->dataProducao.ano, aux->qtDeFardos, aux->duracao);
        printf("Fardo:\n Cultivar: %s - Tipo: %c - Diâmetro: %d", transformaEmNome(aux->tipoDeFardo.cultivar), aux->tipoDeFardo.tipoDeFeno, aux->tipoDeFardo.diametro);
        printf("------------------------------------------------------------------");
    }
}

void alterarDado(Producao* first){
    int cod;
    Producao *aux = NULL;
    printf("Digite o código da produção que deseja alterar: ");
    scanf("%d", &cod);
    if(first!=NULL){
    for(aux=first; aux!=NULL; aux=aux->next){
        if(aux->codigo==cod)break;
    }
    if(aux->codigo==cod){
        char cult[20];
        Fardo fardo;
        printf("\nDigite o cultivar do fardo: ");
        scanf("%s", cult);
        fardo.cultivar = transformaEmNumero(cult);

        printf("\nDigite o tipo de feno do fardo(A, B ou C): ");
        scanf(" %c", &fardo.tipoDeFeno);

        printf("\nDigite o diâmetro do fardo: ");
        scanf("%d", &fardo.diametro);

        printf("Data da produção, no formato 00 00 0000 (dia mês ano): ");
        scanf("%d %d %d", &aux->dataProducao.dia, &aux->dataProducao.mes, &aux->dataProducao.ano);


        printf("\nDigite a quantidade de fardos da produção: ");
        scanf(" %d", &aux->qtDeFardos);

        printf("Duração da produção: ");
        scanf(" %f", &aux->duracao);
    
        aux->tipoDeFardo = fardo;
    }
    }
}
void excluirDado(Producao* first, int cod){
    Producao *aux = NULL;
    for(aux=first; aux!=NULL; aux = aux->next){
        if(aux->codigo==cod)break;
    }
    if(aux->codigo==cod){
        if(aux->next==NULL){
            aux->prev->next = NULL;
            free(aux);
        }else{
            aux->prev->next = aux->next;
            aux->next->prev = aux->prev;
            free(aux);
        }
    }
}
void consultarCultivar(Producao* first){
    char cult[20];
    printf("\nDigite o cultivar que deseja buscar: ");
    scanf("%s", cult);
    int a = transformaEmNumero(cult);
    if(a==-1){
        printf("Cultivar inválido");
    }else{
        int somaA=0;
        int somaB=0;
        int somaC=0;
        Producao *aux = (Producao*)malloc(sizeof(Producao));
        for(aux = first; aux!=NULL; aux=aux->next){
            if(aux->tipoDeFardo.cultivar==a){
                if(aux->tipoDeFardo.tipoDeFeno=='A'){
                    somaA+=aux->qtDeFardos;
                }
                else if(aux->tipoDeFardo.tipoDeFeno=='B'){
                    somaB+=aux->qtDeFardos;
                }else{
                    somaC+=aux->qtDeFardos;
                }
            }
        }
        printf("\n%s: Feno tipo A - %d",cult, somaA);
        printf("\n%s: Feno tipo B - %d",cult, somaB);
        printf("\n%s: Feno tipo C - %d",cult, somaC);
    }
}
void consultarData(Producao *first){
    int dia, mes, ano;
    printf("Data que deseja consultar, no formato 00 00 0000 (dia mês ano): ");
    scanf("%d %d %d", &dia, &mes, &ano);
    Producao *aux = (Producao*)malloc(sizeof(Producao));
    for(aux = first; aux!=NULL; aux=aux->next){
        if(aux->dataProducao.dia==dia && aux->dataProducao.mes==mes && aux->dataProducao.ano == ano){
            printf("\n%d/%d/%d: %s - %c - %d",dia, mes, ano, transformaEmNome(aux->tipoDeFardo.cultivar), aux->tipoDeFardo.tipoDeFeno, aux->qtDeFardos);
        }
    }


}
int main() {
    int op;
    printf("Escolha 1 opção:\n1 - Incluir Produção\n2 - Consultar\n3 - Alterar\n4 - Excluir\n5 - Listar todos\n6 - Sair\n");
    scanf("%d",&op);
    Producao *first = NULL;   
    while(op!=6){
        if(op == 1){
            first = incluirProducao(first);
        }else if(op == 2){
                if(first==NULL){
                printf("Dados ainda não foram adicionados");
            }else{
                int escolha;
                printf("Digite 1 para consultar pelo cultivar e 2 para consultar pela data: ");
                scanf("%d", &escolha);
                if(escolha==1){
                    consultarCultivar(first);
                }else if(escolha==2){
                    consultarData(first);
                }else{printf("Escolha Inválida");}
                
            }
        }else if(op == 3){
            if(first==NULL){
                printf("Dados ainda não foram adicionados");
            }else{
                alterarDado(first);
            }
        }else if(op == 4){
            if(first==NULL){
                printf("Dados ainda não foram adicionados");
            }else{
                int cod;
                printf("Digite o código da produção que deseja excluir: ");
                scanf("%d", &cod);
                if(cod==first->codigo){
                    if(first->next==NULL){
                        first=NULL;
                    }else{Producao *aux = NULL;
                    aux = first;
                    first = first->next;
                    first->prev=NULL;
                    free(aux);}
                }else{
                    excluirDado(first, cod);
                }
            }
        }else if(op == 5){
            if(first==NULL){
                printf("Dados ainda não foram adicionados");
            }else{
                listarTodos(first);
            }
        }else if(op == 6){
        }else{
            printf("Opção Inválida\n");
        }
        printf("\nEscolha 1 opção:\n1 - Incluir Produção\n2 - Consultar\n3 - Alterar\n4 - Excluir\n5 - Listar todos\n6 - Sair\n");
        scanf("%d",&op);
    }
    return 0;
}
