#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "2345-37Feno.h"

int ifExist(Producao *first, int x){
    Producao *aux = first;              // Função pra ver se o código digitado já está na lista.
    for (int i=0;aux!=NULL;i++){        // Retorna 1 se já existir, 0 se não existir.
        if (aux->codigo==x){
            return 1;
        }else {
            aux = aux->next;
        }
        }
    return 0;    
}

void printProd(Producao *p){
    printf("Produção nº %d:\n",p->codigo);
    printf("Data: %d/%d/%d;\n", p->data.dia, p->data.mes, p->data.ano);
    printf("Fardo:\n  Cultivar: %s;\n  Tipo de Feno: %c;\n  Diâmetro: %d.\n", p->tipoFardo.cultivar, p->tipoFardo.tipoDeFeno, p->tipoFardo.diametro);
    printf("Quantidade de fardos: %d;\n",p->qtFardos);
    printf("Duração da produção: %.1f.\n",p->duracao);
    return;
}

Producao *incluirProd(Producao *first){
    Producao *p = (Producao *)malloc(sizeof(Producao)), *aux= first;
    printf("Digite o código da produção: "); scanf("%d", &p->codigo);
    if (p->codigo<0){
        printf("Código inválido. Tente novamente.\n");
        return aux;
    }
    if (ifExist(first,p->codigo)==1) {
        printf("Código já existe na lista. Tente novamente.\n");
        return aux;
    }
    printf("Digite a data do fardo (formato DD/MM/AAAA): "); scanf("%d/%d/%d", &p->data.dia, &p->data.mes, &p->data.ano);
    printf("Digite a cultivar do fardo: "); scanf("%s",p->tipoFardo.cultivar);
    printf("Digite o tipo de feno do fardo (A,B,C): "); scanf(" %c",&p->tipoFardo.tipoDeFeno);
    printf("Digite o diâmetro do fardo (80-160cm): "); scanf("%d",&p->tipoFardo.diametro);
    if (p->tipoFardo.diametro<80 || p->tipoFardo.diametro>160){
        printf("Diâmetro inválido. Tente novamente.\n");
        return aux;
    }
    printf("Digite a quantidade de fardos: "); scanf("%d",&p->qtFardos);
    printf("Digite a duração da produção: "); scanf("%f",&p->duracao);
    if (aux==NULL){
        first = p;
        p->next = NULL;
        p->prev = NULL;
    }else {
        for (int i=0; aux->next!=NULL; i++){
            aux = aux->next;
        }
        aux->next = p;
        p->prev = aux;
        p->next = NULL;
    }
    printf("Produção inserida com sucesso.\n\n");
    printProd(p);
    return first;
}

Producao *excluirProd(Producao *first,int codigo){
    Producao *aux = first;
    while (aux!=NULL && aux->codigo!=codigo){
        aux = aux->next;
    } if (aux == NULL) {
        printf("Código não encontrado. Redirecionando...\n");
        return aux;
    } if (first == aux) {
        first = aux->next;
    } if (aux->prev != NULL) {
        aux->prev->next = aux->next;
    } if (aux->next != NULL) {
        aux->next->prev = aux->prev;
    }
    free(aux);
    printf("Elemento com o código %d removido com sucesso.\n", codigo);
    return first;
}

void alterarProd(Producao *first, int codigo){
    Producao *aux=first;
    while (aux!=NULL && aux->codigo!=codigo){
        aux = aux->next;
    }
    if (aux==NULL) return; // código não encontrado
    //
    printProd(aux);
    int opcao;
    printf("Selecione um item:\n\n1) Editar código;\n2) Mudar data;\n3) Editar fardo\n4) Mudar quantidade de fardos;\n5) Editar duração.\n6) Excluir produção.\n\n(1,2,3,4,5,6): ");
    scanf("%d",&opcao);
    if (opcao==1){
        int novocodigo;
        printf("Digite o código novo: "); scanf("%d",&novocodigo);
        if (ifExist(first,novocodigo)==1){
            printf("Código já existe na lista. Tente novamente.\n");
            printf("--------------------\n");
            alterarProd(first,codigo);
        } else{
            aux->codigo = novocodigo;
            return;
        }
    } else if (opcao==2){
        printf("Digite a nova data do fardo (formato DD/MM/AAAA): "); scanf("%d/%d/%d", &aux->data.dia, &aux->data.mes, &aux->data.ano);
        return;
    } else if (opcao==3){
        char opcaoo;
        printf("Digite o subitem que deseja editar:\n\na) Cultivar;\nb) Tipo de Feno;\nc) Diâmetro.\n\n(a,b,c): ");
        scanf(" %c",&opcaoo);
        if (opcaoo=='a' || opcaoo=='A'){
            printf("Digite o novo cultivar: ");
            scanf("%s",aux->tipoFardo.cultivar);
            printf("Mudança realizada com sucesso. Voltando ao início.\n");
            printf("--------------------\n");
        } else if (opcaoo=='b' || opcaoo=='B'){
            printf("Digite o novo tipo de feno: ");
            scanf(" %c",&aux->tipoFardo.tipoDeFeno);
            printf("Mudança realizada com sucesso. Voltando ao início.\n");
            printf("--------------------\n");
        } else if (opcaoo=='c' || opcaoo=='C'){
            printf("Digite o novo diâmetro: ");
            scanf("%d",&aux->tipoFardo.diametro);
            printf("Mudança realizada com sucesso. Voltando ao início.\n");
            printf("--------------------\n");
        } else {
            printf("Opção inválida. Redirecionando ao início...\n");
            printf("--------------------\n");
        }
    } else if (opcao==4){
        printf("Digite a nova quantidade de fardos: ");
        scanf("%d",&aux->qtFardos);
        printf("Mudança realizada com sucesso. Voltando ao início.\n");
        printf("--------------------\n");
    } else if (opcao==5){
        printf("Digite a nova duração (em dias): ");
        scanf("%f",&aux->duracao);
        printf("Mudança realizada com sucesso. Voltando ao início.\n");
        printf("--------------------\n");
    } else if (opcao==6){
        excluirProd(first,aux->codigo);
        return;
    } else {
        printf("Opção inválida. Redirecionando ao início...\n");
        printf("--------------------\n");
    }
    return;
}

void printTudo(Producao *first){
    Producao *aux = first;
    if (aux==NULL){
        printf("Nenhuma produção foi adicionada. Redirecionando...\n");
        return;
    } else{
        printf("Código      Data               Cultivar       Tipo de Feno     Diâmetro       Quantidade     Duração\n");
        for (int i=0; aux!=NULL;i++){
            printf("%d           %d/%d/%d           %s          %c              %d             %d              %.1f\n",aux->codigo, aux->data.dia, aux->data.mes, aux->data.ano, aux->tipoFardo.cultivar, aux->tipoFardo.tipoDeFeno, aux->tipoFardo.diametro, aux->qtFardos, aux->duracao);
            aux = aux->next;
        }
        return;
    }
}

void consultaProd(Producao *first){
    Producao *aux = first; int opcao, somaA=0, somaB=0, somaC=0;
    printf("Deseja consultar por cultivar (1) ou por data (2)? "); scanf("%d", &opcao);
    if (opcao==1){
        char opcaocult[20];
        printf("Digite a cultivar que deseja consultar: "); scanf("%s",opcaocult);
        for (int i=0;aux!=NULL;i++){
            if (strcmp(aux->tipoFardo.cultivar,opcaocult)==0){
                if (aux->tipoFardo.tipoDeFeno=='a' || aux->tipoFardo.tipoDeFeno=='A'){
                    somaA = somaA + aux->qtFardos;
                } else if (aux->tipoFardo.tipoDeFeno=='b' || aux->tipoFardo.tipoDeFeno=='B'){
                    somaB = somaB + aux->qtFardos;
                } else if (aux->tipoFardo.tipoDeFeno=='c' || aux->tipoFardo.tipoDeFeno=='C'){
                    somaC = somaC + aux->qtFardos;
                }
            }
            aux=aux->next;
        }
        if (somaA==0 && somaB==0 && somaC==0){
            printf("Não há registros com a chave de busca utilizada.\n");
            printf("--------------------\n");
            return;
        } else{
            printf("%s:\n\nTipo A: %d;\nTipo B: %d;\nTipo C: %d.\n", opcaocult, somaA, somaB, somaC);
            printf("--------------------\n");
            return;
        }
    } else if (opcao==2){
        printf("Digite a data que deseja consultar: (DD/MM/AAAA) ");
        Data busca; scanf("%d/%d/%d", &busca.dia, &busca.mes, &busca.ano);
        for (int i=0;aux!=NULL;i++){
            if (aux->data.dia==busca.dia && aux->data.mes==busca.mes && aux->data.ano==busca.ano){
                if (aux->tipoFardo.tipoDeFeno=='a' || aux->tipoFardo.tipoDeFeno=='A'){
                    somaA = somaA + aux->qtFardos;
                } else if (aux->tipoFardo.tipoDeFeno=='b' || aux->tipoFardo.tipoDeFeno=='B'){
                    somaB = somaB + aux->qtFardos;
                } else if (aux->tipoFardo.tipoDeFeno=='c' || aux->tipoFardo.tipoDeFeno=='C'){
                    somaC = somaC + aux->qtFardos;
                }
            }
            aux = aux->next;
        }
        if (somaA==0 && somaB==0 && somaC==0){
            printf("Não há registros com a chave de busca utilizada.\n");
            printf("--------------------\n");
            return;
        } else{
            printf("%d/%d/%d:\n\nTipo A: %d;\nTipo B: %d;\nTipo C: %d.\n", busca.dia, busca.mes, busca.ano, somaA, somaB, somaC);
            printf("--------------------\n");
            return;
        }
    }
}

void menu(Producao *first){
    int oop; Producao *aux=first;
    printf("--------------------\n");
    printf("SISTEMA DE GESTÃO:\n\nSelecione uma opção:\n1) Incluir Produção;\n2) Consultar;\n3) Alterar;\n4) Excluir;\n5) Listar Todos;\n6) Sair.\n");
    printf("--------------------\n");
    printf("(1/2/3/4/5/6): ");
    scanf("%d",&oop);
    if (oop==1){
        aux = incluirProd(aux);
        menu(aux);
    } else if (oop==2){
        consultaProd(aux);
        menu(aux);
    } else if (oop==3){
        int codigor;
        printf("Digite o código da produção que deseja alterar: "); scanf("%d",&codigor);
        alterarProd(aux,codigor);
        menu(aux);
    } else if (oop==4){
        int codigor;
        printf("Digite o código da produção que deseja excluir: "); scanf("%d",&codigor);
        aux = excluirProd(aux,codigor);
        menu(aux);
    } else if (oop==5){
        printTudo(aux);
        menu(aux);
    } else if (oop==6){
        return;
    } else{
        printf("Opção inválida. Redirecionando...\n");
        menu(aux);
    }
}

