#ifndef PRODUCAO_H
#define PRODUCAO_H

// Definições das estruturas
typedef struct data {
  int dia, mes, ano;
}
Data;

typedef struct fardo {
  char cultivar[20];
  char tipoDeFeno;
  int diametro;
}
Fardo;

typedef struct producao {
  int codigo;
  Data dataProducao;
  Fardo tipoDeFardo;
  int qtDeFardos;
  float duracao;
}
Producao;

typedef struct TLista {
  Producao prod;
  struct TLista * prev, * next;
}
Lista;

typedef struct tsentinela {
  Lista * head, * tail;
}
Sentinela;

// Assinaturas das funções
Sentinela incluirProducao(Sentinela s);
void consultarData(Data d, Sentinela s);
void consultarCultivar(Sentinela s, char c[]);
void alterarProducao(Sentinela s, int codigo);
Sentinela excluirProducao(Sentinela s);
void listarTudo(Sentinela s);
void menu();

#endif