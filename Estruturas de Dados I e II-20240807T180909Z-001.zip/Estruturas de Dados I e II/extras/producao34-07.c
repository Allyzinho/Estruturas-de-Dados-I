#include "producao34-07.h"

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

// Incluir Produção
Sentinela incluirProducao(Sentinela s) {
  Fardo fardo;
  Data data;
  Producao producao;
  Lista * p, * aux;
  int codvali = 1, loop = 1, codigoproduto = 0, diametro, fardos = 0, dia = 0, mes = 0, ano = 0;
  float dupro;
  char tipo;

  //Usuario tem que informar um codigo valido, se não ele vai pedir novamente
  while (loop == 1) {
    printf("Código desejado: ");
    scanf("%d", & codigoproduto);
    //Faz a validação do codigo para não se ter dois registros com o mesmo codigo
    codvali = 1;
    for (aux = s.head; aux != NULL; aux = aux -> next) {
      if (aux -> prod.codigo == codigoproduto) {
        printf("Código de produção já existe. Insira um código válido.\n");
        codvali = 0;
      }
    }
    //Se for um codigo valido atribui o valor
    if (codvali == 1) {
      producao.codigo = codigoproduto;
      loop = 0;
    }
  }
  //getchar();

  //Resetando as variaveis
  loop = 1;
  codvali = 1;

  while (loop == 1) {
    printf("Data da produção (ex: 11 12 2023): ");
    scanf("%d %d %d", & dia, & mes, & ano);
    //Faz a validação da data 
    if ((dia > 0 && dia <= 31) && (mes > 0 && mes <= 12) && (ano > 0)) {
      //Se a data for valida atribui o valor
      data.dia = dia;
      data.mes = mes;
      data.ano = ano;
      loop = 0;
    } else {
      printf("Data invalida\n");
      //codvali = 0;
    }
  }

  printf("Cultivar: ");
  scanf("%s", fardo.cultivar);

  //Resetando as variaveis
  loop = 1;
  codvali = 1;

  while (loop == 1) {
    printf("Tipo de feno (Tipos: A, B ou C): ");
    scanf(" %c", & tipo);
    //Faz a validação do tipo para não se ter um tipo invalido
    if (tipo == 'A' || tipo == 'B' || tipo == 'C' || tipo == 'a' || tipo == 'b' || tipo == 'c') {
      //Se for um codigo valido atribui o valor
      fardo.tipoDeFeno = tipo;
      loop = 0;
    } else {
      printf("Tipo invalido\n");
      //codvali = 0;
    }
  }

  //Resetando as variaveis
  loop = 1;
  codvali = 1;

  while (loop == 1) {
    printf("Diâmetro (80 cm a 160 cm): ");
    scanf("%d", & diametro);
    //Faz a validação do diametro para não se ter um diametro invalido
    if (diametro >= 80 && diametro <= 160) {
      //Se for um diametro valido atribui o valor
      fardo.diametro = diametro;
      loop = 0;
    } else {
      printf("Diametro invalido\n");
      //codvali = 0;
    }
  }

  //Resetando as variaveis
  loop = 1;
  codvali = 1;

  while (loop == 1) {
    printf("Quantidade de fardos: ");
    scanf(" %d", & fardos);
    //Faz a validação da quantidade para não se ter um quantidade nula
    if (fardos > 0) {
      //Se for uma quantidade valida atribui o valor
      producao.qtDeFardos = fardos;
      loop = 0;
    } else {
      printf("Quantidade não pode ser nula.\n");
      codvali = 0;
    }
  }

  //Resetando as variaveis
  loop = 1;
  codvali = 1;

  while (loop == 1) {
    printf("Duração do periodo de produção: ");
    scanf(" %f", & dupro);
    //Faz a validação da duração para não se ter uma duração nula
    if (dupro > 0) {
      //Se for uma duração valida atribui o valor
      producao.duracao = dupro;
      loop = 0;
    } else {
      printf("Duração do periodo de produção não pode ser nula.\n");
      codvali = 0;
    }
  }

  producao.dataProducao = data;
  producao.tipoDeFardo = fardo;

  p = (Lista * ) malloc(sizeof(Lista));
  p -> prod = producao;
  p -> next = NULL;
  p -> prev = NULL;
  if (s.head == NULL) {
    s.head = p;
    s.tail = p;
  } else {
    s.tail -> next = p;
    p -> prev = s.tail;
    s.tail = p;
  }
  return s;
}

// Consultar por Data
void consultarData(Data d, Sentinela s) {
  Lista * aux;
  int encontrou = 0;

  for (aux = s.head; aux != NULL; aux = aux -> next) {
    if (aux -> prod.dataProducao.dia == d.dia && aux -> prod.dataProducao.mes == d.mes && aux -> prod.dataProducao.ano == d.ano) {
      if (!encontrou) {
        printf("%02d/%02d/%04d: %s - %c - %d \n", d.dia, d.mes, d.ano, aux -> prod.tipoDeFardo.cultivar, aux -> prod.tipoDeFardo.tipoDeFeno, aux -> prod.qtDeFardos);
        encontrou = 1;
      } else {
        printf("\n%02d/%02d/%04d: %s - %c - %d \n", d.dia, d.mes, d.ano, aux -> prod.tipoDeFardo.cultivar, aux -> prod.tipoDeFardo.tipoDeFeno, aux -> prod.qtDeFardos);
      }
    }
  }

  if (!encontrou) {
    printf("Nenhum registro encontrado para a data: %02d/%02d/%04d\n", d.dia, d.mes, d.ano);
  }
}

// Consultar por Cultivar
void consultarCultivar(Sentinela s, char c[]) {
  Lista * aux;
  int encontrou = 0;

  for (aux = s.head; aux != NULL; aux = aux -> next) {
    if (strcmp(aux -> prod.tipoDeFardo.cultivar, c) == 0) {
      if (!encontrou) {
        printf("%s: %c - %d \n", aux -> prod.tipoDeFardo.cultivar, aux -> prod.tipoDeFardo.tipoDeFeno, aux -> prod.qtDeFardos);
        encontrou = 1;
      } else {
        printf("\n%s: %c - %d \n", aux -> prod.tipoDeFardo.cultivar, aux -> prod.tipoDeFardo.tipoDeFeno, aux -> prod.qtDeFardos);
      }
    }
  }

  if (!encontrou) {
    printf("Nenhum registro encontrado para a cultivar: %s\n", c);
  }
}

// Alterar Produção
void alterarProducao(Sentinela s, int codigo) {
  Lista * aux;
  int codvali = 1, loop = 1, codigoproduto = 0, diametro, fardos = 0, dia = 0, mes = 0, ano = 0;
  float dupro;
  char tipo;

  for (aux = s.head; aux != NULL; aux = aux -> next) {
    if (aux -> prod.codigo == codigo) {
      printf("Registro encontrado. Escolha o campo que deseja alterar:\n");
      printf("1. Código desejado\n");
      printf("2. Data da produção\n");
      printf("3. Cultivar\n");
      printf("4. Tipo de feno\n");
      printf("5. Diâmetro\n");
      printf("6. Quantidade de fardos\n");
      printf("7. Duração do periodo de produção\n");
      printf("8. Cancelar\n");

      int op;
      scanf("%d", & op);

      //Resetando as variaveis
      loop = 1;
      codvali = 1;

      switch (op) {
      case 1:
        while (loop == 1) {
          printf("Novo código desejado: ");
          scanf(" %d", & codigoproduto);
          //Faz a validação do codigo para não se ter dois registros com o mesmo codigo
          codvali = 1;
          for (aux = s.head; aux != NULL; aux = aux -> next) {
            if (aux -> prod.codigo == codigoproduto) {
              printf("Código de produção já existe. Insira um código válido.\n");
              codvali = 0;
            }
          }
          //Se for um codigo valido atribui o valor
          if (codvali == 1) {
            aux -> prod.codigo = codigoproduto;
            loop = 0;
          }
        }
        break;
      case 2:
        while (loop == 1) {
          printf("Nova data da produção (ex: 11 12 2023): ");
          scanf("%d %d %d", & dia, & mes, & ano);
          //Faz a validação da data 
          if ((dia > 0 && dia <= 31) && (mes > 0 && mes <= 12) && (ano > 0)) {
            //Se a data for valida atribui o valor
            aux -> prod.dataProducao.dia = dia;
            aux -> prod.dataProducao.mes = mes;
            aux -> prod.dataProducao.ano = ano;
            loop = 0;
          } else {
            printf("Data invalida\n");
            codvali = 0;
          }
        }
        break;
      case 3:
        printf("Novo cultivar: ");
        scanf("%s", aux -> prod.tipoDeFardo.cultivar);
        break;
      case 4:
        while (loop == 1) {
          printf("Novo tipo de feno (Tipos: A, B ou C): ");
          scanf(" %c", & tipo);
          //Faz a validação do tipo para não se ter um tipo invalido
          if (tipo == 'A' || tipo == 'B' || tipo == 'C' || tipo == 'a' || tipo == 'b' || tipo == 'c') {
            //Se for um codigo valido atribui o valor
            aux -> prod.tipoDeFardo.tipoDeFeno = tipo;
            loop = 0;
          } else {
            printf("Tipo invalido\n");
            codvali = 0;
          }
        }
        break;
      case 5:
        while (loop == 1) {
          printf("Novo diâmetro (80 cm a 160 cm): ");
          scanf("%d", & diametro);
          //Faz a validação do diametro para não se ter um diametro invalido
          if (diametro >= 80 && diametro <= 160) {
            //Se for um diametro valido atribui o valor
            aux -> prod.tipoDeFardo.diametro = diametro;
            loop = 0;
          } else {
            printf("Diametro invalido\n");
            codvali = 0;
          }
        }
        break;
      case 6:

        while (loop == 1) {
          printf("Nova quantidade de fardos: ");
          scanf(" %d", & fardos);
          //Faz a validação da quantidade para não se ter um quantidade nula
          if (fardos > 0) {
            //Se for uma quantidade valida atribui o valor
            aux -> prod.qtDeFardos = fardos;
            loop = 0;
          } else {
            printf("Quantidade não pode ser nula.\n");
            codvali = 0;
          }
        }
        break;
      case 7:
        while (loop == 1) {
          printf("Duração do periodo de produção: ");
          scanf(" %f", & dupro);
          //Faz a validação da duração para não se ter uma duração nula
          if (dupro > 0) {
            //Se for uma duração valida atribui o valor
            aux -> prod.duracao = dupro;
            loop = 0;
          } else {
            printf("Duração do periodo de produção não pode ser nula.\n");
            codvali = 0;
          }
        }
        break;
      case 8:
        printf("Operação de alteração cancelada.\n");
        return;
      default:
        printf("Opção inválida.\n");
      }

      printf("Registro alterado com sucesso.\n");
      return;
    }
  }

  printf("Nenhum registro encontrado com o código %d.\n", codigo);
}

// Excluir Produção
Sentinela excluirProducao(Sentinela s) {
  Lista * aux, * prev = NULL;
  int codigo;
  printf("Código da produção que deseja excluir: ");
  scanf("%d", & codigo);

  for (aux = s.head; aux != NULL;  aux = aux -> next) {
    if (aux -> prod.codigo == codigo) {
      if (prev == NULL) {
        s.head = aux -> next;
      } else {
        prev -> next = aux -> next;
      }
      if (aux == s.tail) {
        s.tail = prev;
      }
      free(aux);
      printf("Registro excluído com sucesso.\n");
      return s;
    }
  	prev = aux;  

  }

  printf("Nenhum registro encontrado com o código %d.\n", codigo);
  return s;
}

// Listar Tudo
void listarTudo(Sentinela s) {
  Lista * aux;

  printf("Lista de todos os registros de produção:\n");

  for (aux = s.head; aux != NULL; aux = aux -> next) {
    printf("Código: %d\n", aux -> prod.codigo);
    printf("Data da produção: %02d/%02d/%04d\n", aux -> prod.dataProducao.dia, aux -> prod.dataProducao.mes, aux -> prod.dataProducao.ano);
    printf("Cultivar: %s\n", aux -> prod.tipoDeFardo.cultivar);
    printf("Tipo de feno: %c\n", aux -> prod.tipoDeFardo.tipoDeFeno);
    printf("Diâmetro: %d\n", aux -> prod.tipoDeFardo.diametro);
    printf("Quantidade de fardos: %d\n", aux -> prod.qtDeFardos);
    printf("Duração do periodo de produção: %.2f\n", aux -> prod.duracao);
    printf("---------------------------\n");
  }
}

// Menu
void menu() {
  printf("1. Incluir Produção \n");
  printf("2. Consultar \n");
  printf("3. Alterar \n");
  printf("4. Excluir \n");
  printf("5. Listar Tudo \n");
  printf("6. Sair \n");
  printf("O que você deseja fazer: ");
  return;
}
