#include <stdio.h>

int main(){

    int time, gols, campeao, soma;
    
    for (time = 1; time < 4; time++){
        
        printf("Time: ");
        scanf("%d", &time);
        printf("Gols: ");
        scanf("%d", &gols);
        
        if(time == 'X'){
            break;
        }
        soma += gols;
        printf("Campeão: %d\n", campeao);
        printf("Gols: %d\n", soma);
    }

    return 0;
}